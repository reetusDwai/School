# Complete the comments below
# Name:
# Assignment: Lab 1, Exercise 2: mean.py
# Date:
# List any issues you had with this lab
