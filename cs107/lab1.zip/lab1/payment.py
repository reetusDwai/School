# Complete the comments below
# Name:
# Assignment: Lab 1, Exercise 1: payment.py
# Date:
# List any issues you had with this lab