# Complete the comments below
# Name:
# Assignment: Lab 1, Exercise 3: polygons.py
# Date:
# List any issues you had with this lab
import turtle

turtle.setup(400, 400)
window = turtle.Screen()
window.title('Lab 1: Spiral')

t = turtle.Turtle()

# Your code goes here

    
turtle.done()