# Complete the comments below
# Name:
# Assignment: Lab 1, Exercise 3: polygons.py
# Date:
# List any issues you had with this lab
import turtle

turtle.setup(1000, 600)
window = turtle.Screen()
window.title('Lab 1: Polygons')

t = turtle.Turtle()

t.penup()
t.setposition(-450, 0)
t.pendown()

# Your code goes here

turtle.done()